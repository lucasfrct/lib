A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/XmgxLg.

 Ken Burns effects with Vegas Background SlideShow V2, a jQuery/Zepto plugin.