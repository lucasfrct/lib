LetterFX
========

A jQuery plugin to apply animated, visual effects to letters, words or other text patterns.

example usage:

    $(element).letterfx({"fx":"fly-right fly-bottom spin"})


[More Info](http://tuxsudo.com/code/project/letterfx)
