<?php

/**
 * @author Antonio Spinelli <antonio.spinelli@kanui.com.br>
 */
interface NFSeTest_Provider_ProviderInterface
{

    public static function response(array $params);
}
