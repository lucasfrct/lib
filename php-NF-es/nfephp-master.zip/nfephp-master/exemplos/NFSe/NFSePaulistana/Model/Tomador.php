<?php
namespace NFSe\Model;

/**
 * @category   NFePHP
 * @package    NFSe\Dto\Tomador
 * @copyright  Copyright (c) 2008-2015
 * @license    http://www.gnu.org/licenses/lesser.html LGPL v3
 * @author     Thiago Colares <thicolares at gmail dot com>
 * @link       http://github.com/nfephp-org/nfephp for the canonical source repository
 */

class Tomador
{

}

?>