<?php

namespace NFePHP\CTe;

/**
 * Classe para envio dos emails aos interessados
 * @category   NFePHP
 * @package    NFePHP\CTe\MailCTe
 * @copyright  Copyright (c) 2008-2015
 * @license    http://www.gnu.org/licenses/lesser.html LGPL v3
 * @author     Roberto L. Machado <linux.rlm at gmail dot com>
 * @link       http://github.com/nfephp-org/nfephp for the canonical source repository
 */

class MailCTe
{
    
}
