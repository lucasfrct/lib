<?php

namespace NFePHP\CTe;

/**
 * Classe para impressão dos documentos ficais
 * @category   NFePHP
 * @package    NFePHP\CTe\PrintCTe
 * @copyright  Copyright (c) 2008-2015
 * @license    http://www.gnu.org/licenses/lesser.html LGPL v3
 * @author     Roberto L. Machado <linux.rlm at gmail dot com>
 * @link       http://github.com/nfephp-org/nfephp for the canonical source repository
 */

class PrintCTe
{
    
}
