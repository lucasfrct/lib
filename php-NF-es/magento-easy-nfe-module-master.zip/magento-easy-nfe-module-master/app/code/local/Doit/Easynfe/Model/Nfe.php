<?php

/**
 * Easynfe - NF-e. 
 *
 * @title      Magento Easynfe NF-e
 * @category   General
 * @package    Doit_Easynfe
 * @author     Indexa Development Team <desenvolvimento@indexainternet.com.br>
 * @copyright  Copyright (c) 2011 Indexa - http://www.indexainternet.com.br
 */
class Doit_Easynfe_Model_Nfe {
    
    /**
     * staging server URLs
     */    
    const NFE_TEST_REQUEST_PUT_URL = 'https://staging.doit.com.br/easy-nfe-server/api/v2/nfe';
    const NFE_TEST_REQUEST_URL = 'https://staging.doit.com.br/easy-nfe-server/api/v2/nfe/request/';
    
    const NFE_TEST_REQUEST_URL_BASE = 'https://staging.doit.com.br/easy-nfe-server/';
    
    /**
     * server URLs
     */
    const NFE_REQUEST_PUT_URL = 'https://easynfe.doit.com.br/api/v2/nfe';
    
    const NFE_REQUEST_URL =     'https://easynfe.doit.com.br/api/v2/nfe/request/';
    
    const NFE_REQUEST_URL_BASE = 'https://easynfe.doit.com.br/';
    
    
    /**
     * Starts processing NF-e 
     */
    public function execute() {

        /**
         * get shipment collection
         */
        $mOrderNfe = Mage::getModel('doit_easynfe/sales_order_nf')
                ->getCollection()
                ->addStatusFilter(Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_CREATED);

        $aParams["nfe.NFe"]["nfe.infNFe"]["@versao"] = '3.10';        
        $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.emit"] = $this->_prepareEmitData();

        if (count($mOrderNfe) > 0) {
            foreach ($mOrderNfe as $mNfe) {
                /**
                 * save executed date 
                 */
                $mNfe->setData('executed_at', date('Y-m-d H:i:s'));
                $mNfe->save();

                /**
                 * load sales order shipment
                 */
		
                if ($mNfe->getShipmentId()) {
                    $mOrderShipment = Mage::getModel('sales/order_shipment')->load($mNfe->getShipmentId());
                    $mOrder = $mOrderShipment->getOrder();

                    $mOrder->getIncrementId();  

                    $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.ide"] = $this->_prepareIdeData($mOrderShipment);
                    $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.dest"] = $this->_prepareCustomerData($mOrder);
                    $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.det"] = $this->_prepareItems($mOrderShipment);
                    $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.total"] = $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.det"]["nfe.total"];
                    $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.transp"]["nfe.modFrete"] = '0'; // emitente

                    $aParams["nfe.organization"] = Mage::getStoreConfig('doit_easynfe/acesso/chave');
                    $aParams["nfe.cert"]["easynfe.certData"] = Mage::getModel('doit_easynfe/certificado')->load('1')->getCertificado();
                    $aParams["nfe.cert"]["easynfe.certPasswd"] = Mage::getStoreConfig('doit_easynfe/acesso/password');

                    $aParams["nfe.NFe"]["nfe.infNFe"]["nfe.infAdic"]["nfe.infCpl"] = "Número do Pedido:  " .$mOrder->getIncrementId();

                    unset($aParams["nfe.NFe"]["nfe.infNFe"]["nfe.det"]["nfe.total"]);

                    $this->_nfeSend($mNfe->getId(), $aParams);

                }
            }
        }
        return $this;
    }

    /**
     * start communication with easyNFe
     * 
     * @param array $aParams 
     */
    private function _nfeSend($nfeId, $aParams) {
        //echo '<pre>';print_r($aParams);die();
        $mRequest = Mage::getModel('doit_easynfe/sales_order_request');
        
        $mRequest->setData('request', Zend_Json::encode($aParams));
        $mRequest->setData('nfe_nf_id', $nfeId);
        $mRequest->setData('status', Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_CREATED);
        $mRequest->setData('created_at', date('Y-m-d H:i:s'));
        
        $mRequest->save();

        if( Mage::getStoreConfig('doit_easynfe/config/tpamb') == '1' ){
            $url = self::NFE_REQUEST_PUT_URL;
        }else{
            $url = self::NFE_TEST_REQUEST_PUT_URL;
        }

        /**
         * prepare curl request
         */
        $defaults = array(
            CURLOPT_POST => 1,
            CURLOPT_HEADER => 0,
            CURLOPT_TIMEOUT => 120,
	        CURLOPT_USERPWD => Mage::getStoreConfig('doit_easynfe/acesso/chave') . ":" . Mage::getStoreConfig('doit_easynfe/acesso/pass'),
            CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
            CURLOPT_POSTFIELDS => Zend_Json::encode($aParams),
            //CURLOPT_POST=> true,
            CURLOPT_CUSTOMREQUEST => "PUT",
            CURLOPT_RETURNTRANSFER => true
        );

        $ch = curl_init($url);
        curl_setopt_array($ch, ($defaults));

        $result = curl_exec($ch);

        if (!$result) {
            $message = curl_error($ch);
            $mRequest->setData('status', Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_ERROR);
        } else {
            $sucess = explode(PHP_EOL, $result);
            $message = $result;
            $mRequest->setData('status', Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_PROCESSING);
        }

        curl_close($ch);
        $mRequest->setData('messages', $message);

        $mRequest->setData('executed_at', date('Y-m-d H:i:s'));
        $mRequest->save();
        
        return $mRequest->getData('messages');
    }

    public function updateInfo(){
        
        /**
         * get shipment collection
         */
        $mNfeRequest = Mage::getModel('doit_easynfe/sales_order_request')
                ->getCollection()
                ->addStatusFilter(Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_PROCESSING);    
        if ($mNfeRequest){
            foreach ($mNfeRequest as $request){
                 $this->_getRequestInfo( $request );
                
            }
        }        
    }
    
    
    private function _getRequestInfo( $request ){
        
        if( Mage::getStoreConfig('doit_easynfe/config/tpamb') == '1' ){
            $url = self::NFE_REQUEST_URL;
        }else{
            $url = self::NFE_TEST_REQUEST_URL;
        }
        
        if( Mage::getStoreConfig('doit_easynfe/config/tpamb') == '1' ){
            $url_base = self::NFE_REQUEST_URL_BASE;
            $url_base_key = self::NFE_REQUEST_PUT_URL;
        }else{
            $url_base = self::NFE_TEST_REQUEST_URL_BASE;
            $url_base_key = self::NFE_TEST_REQUEST_PUT_URL;
        }
        
        //$httpmessage = file($url . $request->getMessages() );
	    $defaults = array(
            CURLOPT_HEADER => 0,
            CURLOPT_TIMEOUT => 120,
	        CURLOPT_USERPWD => Mage::getStoreConfig('doit_easynfe/acesso/chave') . ":" . Mage::getStoreConfig('doit_easynfe/acesso/pass'),
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_RETURNTRANSFER => true
        );

        $ch = curl_init($url.$request->getMessages());
        curl_setopt_array($ch, ($defaults));        

	    $result = curl_exec($ch);
	
	    $httpmessage = explode(PHP_EOL, $result);

        $mRequest = Mage::getModel('doit_easynfe/sales_order_request')->load($request->getId());
        $orderId = Mage::getModel('doit_easynfe/sales_order')->load( Mage::getModel('doit_easynfe/sales_order_nf')->load( $mRequest->getNfeNfId() )->getNfOrderId() )->getOrderId();
        $mOrder = Mage::getModel('sales/order')->load($orderId);
        /* @var $mOrder Mage_Sales_Model_Order */  
        
        if( is_array($httpmessage) ){
             
            if( 'AUTHORIZED' == str_replace(PHP_EOL, '', $httpmessage[0]) ){
            	$context = stream_context_create(array(
            			'http' => array(
            					'header'  => "Authorization: Basic " . base64_encode(Mage::getStoreConfig('doit_easynfe/acesso/chave') . ":" . Mage::getStoreConfig('doit_easynfe/acesso/pass'))
            			)
            	));

            	$access_key = file_get_contents( $url_base_key . '/' . Mage::getStoreConfig('doit_easynfe/acesso/chave') . '/' . Mage::getStoreConfig('doit_easynfe/config/serie') . '/' . $httpmessage[1] . '/accessKey', false, $context);
                
                if( $access_key ){ 
                    
                    /**
                     * check directories
                     */
                    $ioObject = new Varien_Io_File();
                    $destDirectory = Mage::getBaseDir('media') . '/nf/pdf';
                    try {
                        $ioObject->open(array('path' => $destDirectory));
                    } catch (Exception $e) {
                        $ioObject->mkdir($destDirectory, 0777, true);
                        $ioObject->open(array('path' => $destDirectory));
                    }
                    $destDirectory = Mage::getBaseDir('media') . '/nf/tmp';
                    try {
                        $ioObject->open(array('path' => $destDirectory));
                    } catch (Exception $e) {
                        $ioObject->mkdir($destDirectory, 0777, true);
                        $ioObject->open(array('path' => $destDirectory));
                    }
                    $destDirectory = Mage::getBaseDir('media') . '/nf/xml';
                    try {
                        $ioObject->open(array('path' => $destDirectory));
                    } catch (Exception $e) {
                        $ioObject->mkdir($destDirectory, 0777, true);
                        $ioObject->open(array('path' => $destDirectory));
                    }
                    
                    /**
                     * save tmp xml
                     */
                    $tmp_filename = Mage::getBaseDir('media') . '/nf/tmp/'.$access_key.'.xml';
                    $xml_content = file_get_contents( $url_base . 'nfe/' . Mage::getStoreConfig('doit_easynfe/acesso/chave') . '/' . Mage::getStoreConfig('doit_easynfe/config/serie') . '/' . $httpmessage[1] . '?accessKey=' . $access_key);
                    
                    file_put_contents( $tmp_filename, $xml_content);
                    $nfXML = new Zend_Config_Xml( $tmp_filename );
                    
                    if( $nfXML->protNFe->infProt->chNFe ){
                        
                        $xml_filename = Mage::getBaseDir('media') . '/nf/xml/'.$nfXML->protNFe->infProt->chNFe.'.xml';
                        file_put_contents( $xml_filename, $xml_content);
                        
                        $pdf_filename = Mage::getBaseDir('media') . '/nf/pdf/'.$nfXML->protNFe->infProt->chNFe.'.pdf';
                        $pdf_content = file_get_contents( $url_base . 'nfe/' . Mage::getStoreConfig('doit_easynfe/acesso/chave') . '/' . Mage::getStoreConfig('doit_easynfe/config/serie') . '/' . $httpmessage[1] . '/danfe?accessKey=' . $access_key);
                        file_put_contents( $pdf_filename, $pdf_content );
                       
                        $mRequest->setData('messages', $nfXML->protNFe->infProt->chNFe );
                        $mRequest->setData('status', Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_FINISHED);
                        $mRequest->setData('finished_at', date('Y-m-d H:i:s'));

                         /**
                         * change status order
                         */
                        if( $mOrder->canShip() ){
                            $mOrder->setStatus('pending_nf')->save();
                        }else{
                            $mOrder->setStatus('complete_nf')->save();
                        }
                        
                        unlink($tmp_filename);
                        /**/

			 if( Mage::getStoreConfig('doit_easynfe/email/status') ){
		                try{
		                    
		                      // send email
		                     
		                    $objEmail = new Varien_Object();
		                    $config = new Zend_Config_Xml( $xml_filename );

		                    $objEmail->setData('nf', $config->get('NFe')->get('infNFe')->get('ide')->get('nNF'));
                                    $objEmail->setData('mod', $config->get('NFe')->get('infNFe')->get('ide')->get('mod'));
                                    $objEmail->setData('cpf', $config->get('NFe')->get('infNFe')->get('dest')->get('CPF'));
                                    $objEmail->setData('serie', $config->get('NFe')->get('infNFe')->get('ide')->get('serie'));
                                    $objEmail->setData('chave', $config->get('protNFe')->get('infProt')->get('chNFe'));

		                    
		                     // create email and attach files
		                     
		                    $sendMail = Mage::getModel('core/email_template');
		                    $sendMail->getMail()->createAttachment($pdf_content, 
		                                                            'application/pdf', 
		                                                            Zend_Mime::DISPOSITION_ATTACHMENT, 
		                                                            Zend_Mime::ENCODING_BASE64,
		                                                            basename( $pdf_filename )
		                                                            );
		                    $sendMail->getMail()->createAttachment($xml_content, 
		                                                            'text/xml', 
		                                                            Zend_Mime::DISPOSITION_ATTACHMENT, 
		                                                            Zend_Mime::ENCODING_BASE64,
		                                                            basename( $xml_filename )
		                                                            );
				     if( Mage::getStoreConfig('doit_easynfe/email/cc') ){
				     	 $sendMail->getMail()->addCc( Mage::getStoreConfig('doit_easynfe/email/cc') );
				     }
				     if( Mage::getStoreConfig('doit_easynfe/email/email') &&  Mage::getStoreConfig('doit_easynfe/email/nome') ){
				         $senderEmail =  array('name' => Mage::getStoreConfig('doit_easynfe/email/nome'), 'email' => Mage::getStoreConfig('doit_easynfe/email/email') );
				     }else{
				          $senderEmail =  'general';
				     }
		                     $sendMail->sendTransactional(
		                                                'easynfe_email',
		                                                $senderEmail,
		                                                $mOrder->getCustomerEmail(),
		                                                $mOrder->getCustomerName(),
		                        array('nfe' => $objEmail));
		                    
		                    $sendMail->getSentSuccess();
		                    
		                }catch(Exception $e){
		                   
		                }     
			 }
                    }   
                }
                
            }
            if( 'REJECTED' == str_replace(PHP_EOL, '', $httpmessage[0]) ){
                 $mRequest->setData('status', Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_ERROR);
                $mRequest->setData('messages', $httpmessage[1] );
                $mRequest->setData('finished_at', date('Y-m-d H:i:s'));
                /**
                 * change status order
                */
                 $mOrder->setStatus('error_nf')->save(); 
                
            }
            if( 'SEND_FAILED' == str_replace(PHP_EOL, '', $httpmessage[0]) ){
                $mRequest->setData('status', Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_ERROR);
                $mRequest->setData('messages', nl2br(implode(PHP_EOL, $httpmessage)) );
                $mRequest->setData('finished_at', date('Y-m-d H:i:s'));
                /**
                 * change status order
                 */
                $mOrder->setStatus('error_nf')->save();
            }
            
            Mage::getModel('doit_easynfe/sales_order_nf')->load( $mRequest->getNfeNfId() )->setStatus(Doit_Easynfe_Helper_Data::NFE_SHIPMENT_STATUS_FINISHED)->setFinishedAt(date('Y-m-d H:i:s'))->save();
            
            $mRequest->save();
        }
        
    }
    /**
     *  prepare customer data to make requests 
     * 
     * @param Mage_Sales_Model_Order $mOrder
     * 
     * @return array 
     */
    private function _prepareCustomerData($mOrder) {
        $aCustomerData['nfe.CPF'] = ( str_replace(array('.', '/', '-'), array('', '', ''), $mOrder->getCustomerTaxvat()) );
        $aCustomerData['nfe.xNome'] = $mOrder->getCustomerName();
        $aCustomerData['nfe.indIEDest'] = 9;

        $mShipping = $mOrder->getShippingAddress();
        
        $shippingStreet = $mShipping->getStreet();
        $aCustomerData['nfe.enderDest']['nfe.xLgr'] = (string)trim($shippingStreet[0]);
        $aCustomerData['nfe.enderDest']['nfe.nro'] = (string) trim($shippingStreet[1]);
        if (isset($shippingStreet[2]) && $shippingStreet[2]) {
            $aCustomerData['nfe.enderDest']['nfe.xCpl'] = (string) trim($shippingStreet[2]);
        }
        $aCustomerData['nfe.enderDest']['nfe.xBairro'] = trim($shippingStreet[3]);
        $aCustomerData['nfe.enderDest']['nfe.fone'] = (string) trim(str_replace(array('-', ' ', '(', ')'), array('', '', '', ''), $mShipping->getTelephone()));       
        
        $shippingCity = $mShipping->getCity();
        if (is_int($shippingCity)) {
            $aCustomerData['nfe.enderDest']['nfe.cMun'] = $shippingCity;
            $aCustomerData['nfe.enderDest']['nfe.xMun'] = ( Mage::getModel('doit_easynfe/directory_country_region_city')->load( trim($shippingCity) )->getName() );
        } else {
            $shippingCityId = Mage::getModel('doit_easynfe/directory_country_region_city')->load(trim($shippingCity), 'NAME')->getId();
            $aCustomerData['nfe.enderDest']['nfe.cMun'] = $shippingCityId;
            $aCustomerData['nfe.enderDest']['nfe.xMun'] = $shippingCity;
        }

        $aCustomerData['nfe.enderDest']['nfe.UF'] = Mage::getModel('directory/region')->load($mShipping->getRegionId())->getCode();
        $aCustomerData['nfe.enderDest']['nfe.cPais'] = Mage::getModel('doit_easynfe/directory_country')->load($mShipping->getCountryId(), 'country_id')->getId();
        $aCustomerData['nfe.enderDest']['nfe.xPais'] = Mage::app()->getLocale()->getCountryTranslation($mShipping->getCountryId());
        $aCustomerData['nfe.enderDest']['nfe.CEP'] = str_replace('-', '', $mShipping->getPostcode());

        return $aCustomerData;
    }

    /**
     * prepare item information 
     * 
     * @param Mage_Sales_Model_Order_Shipment $mOrderShipment 
     */
    private function _prepareItems($mOrderShipment) {
        $key = 0;
        
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vProd'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vNF'] = '0';

        /**
         * assign shipping values to items 
         */
        $nItems = count( $mOrderShipment->getOrder()->getAllItems() );
        if( $mOrderShipment->getOrder()->getShippingAmount() ){
           

            $vFrete = (string) number_format( $mOrderShipment->getOrder()->getShippingAmount() ,  2,'.', '' );
            $vFreteParcial = number_format( ($vFrete / $nItems), 2,'.', '' );

            for ( $i=0; $i < $nItems; $i++  ){
                $arrFreteParcial[$i] = $vFreteParcial;
            }

            if( ($vFreteParcial * $nItems) < $vFrete ){
                $arrFreteParcial[0] += ($vFrete - ($vFreteParcial * $nItems));
            }  

            if( ($vFreteParcial * $nItems) > $vFrete ){
                $arrFreteParcial[0] += (($vFreteParcial * $nItems) - $vFrete );
            }  
            /**
             * format elements
             */
            for ( $i=0; $i < $nItems; $i++  ){
                $arrFreteParcial[$i] = number_format( $arrFreteParcial[$i],  2,'.', '' );
            }
        }
        
        foreach ($mOrderShipment->getAllItems() as $_shipmentItem) {
            /**
             * load order item
             */
            $mOrderItem = Mage::getModel('sales/order_item')->load($_shipmentItem->getOrderItemId());
            
            $mProduct = Mage::getModel('catalog/product')->load($mOrderItem->getProductId());
            
            $cKey = $key;
            $aOrderItem[$cKey]['@nItem'] = ++$key;

            $aOrderItem[$cKey]['nfe.prod']['nfe.cProd'] = $_shipmentItem->getSku();
            $aOrderItem[$cKey]['nfe.prod']['nfe.cEAN'] = '';
            $aOrderItem[$cKey]['nfe.prod']['nfe.cEANTrib'] ='';
            $aOrderItem[$cKey]['nfe.prod']['nfe.xProd'] = trim( $_shipmentItem->getName() );
            
            $productPrice = $_shipmentItem->getPrice();
            
            $dDescTotal = 0;
            if( $mOrderItem->getDiscountAmount() > 0 ){
                $dDescTotal = number_format( $mOrderItem->getDiscountAmount() * ( $_shipmentItem->getQty() / $mOrderItem->getQtyOrdered()  ),  2,'.', '' );
            }
            $aOrderItem[$cKey]['nfe.prod']['nfe.vDesc'] = $dDescTotal;

            $diff = $mOrderShipment->getOrder()->getTotalPaid() - $mOrderShipment->getOrder()->getGrandTotal();
            $percent = $diff / $mOrderShipment->getOrder()->getGrandTotal();
            $productPrice = $productPrice * (1 + $percent);
                        
            $aOrderItem[$cKey]['nfe.prod']['nfe.vProd'] = (string)number_format( $productPrice * $_shipmentItem->getQty(),  2,'.', '' );
          
            $aOrderItem[$cKey]['nfe.prod']['nfe.indTot'] = '1';

            /**
             * check CFOP code
             */
            $aOrderItem[$cKey]['nfe.prod']['nfe.CFOP'] = ( $this->getCustomerUf($mOrderShipment) == Mage::getStoreConfig('doit_easynfe/emit/cuf') ? '5102' : '6108' );
            $aOrderItem[$cKey]['nfe.prod']['nfe.NCM'] = (string) ( $_shipmentItem->getNfeNcm() ? $_shipmentItem->getNfeNcm() : $mProduct->getNfeNcm() );

            $aOrderItem[$cKey]['nfe.prod']['nfe.uCom'] = (string) ( $_shipmentItem->getNfeUcom() ? $_shipmentItem->getNfeUcom() : $mProduct->getNfeUcom() );
            $aOrderItem[$cKey]['nfe.prod']['nfe.qCom'] = (int)$_shipmentItem->getQty();
            $aOrderItem[$cKey]['nfe.prod']['nfe.vUnCom'] = (string)number_format($productPrice,  2,'.', '' );

            $aOrderItem[$cKey]['nfe.prod']['nfe.uTrib'] = (string) ( $_shipmentItem->getNfeUcom() ? $_shipmentItem->getNfeUcom() : $mProduct->getNfeUcom() );
            $aOrderItem[$cKey]['nfe.prod']['nfe.qTrib'] =  (int) ( $_shipmentItem->getQty() );
            $aOrderItem[$cKey]['nfe.prod']['nfe.vUnTrib'] = (string) number_format( $productPrice,  2,'.', '' );
            
            $vFrete = 0;
            
            if($arrFreteParcial[$cKey] > 0){
                $vFrete = ( $arrFreteParcial[$cKey] * ( $_shipmentItem->getQty() / $mOrderItem->getQtyOrdered() ) ) * (1 + $percent);
                $aOrderItem[$cKey]['nfe.prod']['nfe.vFrete'] = (string)number_format($vFrete,  2,'.', '' );
            }
           
            $vTotal = number_format( ( $productPrice * $_shipmentItem->getQty() ) ,  2,'.', '' );
            
            /**
             * ICMS
             */
            $aOrderItem[$cKey]['nfe.imposto']['nfe.ICMS']['nfe.ICMSSN102']['nfe.orig'] = (string) ( $_shipmentItem->getNfeOrig() ? $_shipmentItem->getNfeOrig() : '0' ) ;
            $aOrderItem[$cKey]['nfe.imposto']['nfe.ICMS']['nfe.ICMSSN102']['nfe.CSOSN'] = '102';

            /**
             * COFINS CST 99
             */
            $aOrderItem[$cKey]['nfe.imposto']['nfe.COFINS']['nfe.COFINSOutr']['nfe.CST'] = '99';
            $aOrderItem[$cKey]['nfe.imposto']['nfe.COFINS']['nfe.COFINSOutr']['nfe.vBC'] = '0';
            $aOrderItem[$cKey]['nfe.imposto']['nfe.COFINS']['nfe.COFINSOutr']['nfe.pCOFINS'] = '0';
            $aOrderItem[$cKey]['nfe.imposto']['nfe.COFINS']['nfe.COFINSOutr']['nfe.vCOFINS'] = '0';
            
            /**
             * PIS CST 99
             */
            $aOrderItem[$cKey]['nfe.imposto']['nfe.PIS']['nfe.PISOutr']['nfe.CST'] = '99';
            $aOrderItem[$cKey]['nfe.imposto']['nfe.PIS']['nfe.PISOutr']['nfe.vBC'] = '0';
            $aOrderItem[$cKey]['nfe.imposto']['nfe.PIS']['nfe.PISOutr']['nfe.pPIS'] = '0';
            $aOrderItem[$cKey]['nfe.imposto']['nfe.PIS']['nfe.PISOutr']['nfe.vPIS'] = '0';
            
            /**
             * sum items
             */
            $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vProd'] += $vTotal;
            $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vNF'] += (($vTotal + $vFrete) - $dDescTotal);
            $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vDesc'] += $dDescTotal;
            
            if($vFrete > 0){
                $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vFrete'] += $vFrete;
            }
        }
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vProd'] = (string)number_format( $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vProd'],  2,'.', '' );
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vNF'] =  (string)number_format( $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vNF'], 2,'.', '' );
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vFrete'] = (string)number_format( $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vFrete'], 2,'.', '' );
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vDesc'] = (string)number_format( $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vDesc'], 2,'.', '' );
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vICMS'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vICMSDeson'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vBC'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vPIS']= '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vCOFINS'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vST'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vBCST'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vSeg'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vII'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vIPI'] = '0';
        $aOrderItem['nfe.total']['nfe.ICMSTot']['nfe.vOutro'] = '0';
        return $aOrderItem;
    }

    /**
     * prepare ide information
     */
    private function _prepareIdeData($mOrderShipment) {

        $aIdeData['nfe.cUF'] = Mage::getStoreConfig('doit_easynfe/config/cuf');
        $aIdeData['nfe.cNF'] = '10000001'; // rewrited on webservice ;
        $aIdeData['nfe.natOp'] = Mage::getStoreConfig('doit_easynfe/config/natop') == '1' ? 'Venda de Mercadorias' : '';
        $aIdeData['nfe.indPag'] = '0'; //$mOrder->getPayment()->getMethod(); // rewrited on webservice 
        $aIdeData['nfe.mod'] = Mage::getStoreConfig('doit_easynfe/config/mod');
        $aIdeData['nfe.serie'] = Mage::getStoreConfig('doit_easynfe/config/serie') ;
        $aIdeData['nfe.nNF'] = '1'; // rewrited on webservice 
        $aIdeData['nfe.dSaiEnt'] = date('Y-m-d'); // data de saida ou entrada do produtogn
        $aIdeData['nfe.hSaiEnt'] = date('H:i:s'); // hora de saida ou entrada do produto
        $aIdeData['nfe.tpNF'] = Doit_Easynfe_Helper_Data::NFE_TPNF_SAIDA; // tipo da operação 0 - entrada, 1 - saida
        $aIdeData['nfe.cMunFG'] = Mage::getStoreConfig('doit_easynfe/config/cmunfg');
        $aIdeData['nfe.tpImp'] = Mage::getStoreConfig('doit_easynfe/config/tpimp'); // tipo da impressao 1 - retrato, 2 - paisagem
        $aIdeData['nfe.tpEmis'] = Doit_Easynfe_Helper_Data::NFE_TPEMIS_NORMAL; // tipo de emissao 
        $aIdeData['nfe.cDV'] = '1'; // send as null 
        $aIdeData['nfe.tpAmb'] = Mage::getStoreConfig('doit_easynfe/config/tpamb'); // tipo de emissao 
        $aIdeData['nfe.finNFe'] = Doit_Easynfe_Helper_Data::NFE_FINNFE_NORMAL; // numero da nota fiscal
        $aIdeData['nfe.procEmi'] = Doit_Easynfe_Helper_Data::NFE_PROCEMI_DEFAULT; // tipo de emissao
        $aIdeData['nfe.verProc'] = 1; //tipo de emissao
        $aIdeData['nfe.indFinal'] = Doit_Easynfe_Helper_Data::NFE_TIPO_CONSUMIDOR; // tipo do consumidor (1 - consumidor final)
        $aIdeData['nfe.indPres'] = Doit_Easynfe_Helper_Data::NFE_PRESENCA_COMPRADOR_ESTABELECIMENTO; // presença do comprador no estabelecimento (9 - operação não presencial, outros.)        
        $aIdeData['nfe.idDest'] = ( $this->getCustomerUf($mOrderShipment) == Mage::getStoreConfig('doit_easynfe/emit/cuf') ? '1' : '2' );
        return $aIdeData;
    }

    /**
     *  prepare company data to make requests 
     * 
     * @return array 
     */
    private function _prepareEmitData() {

        $aEmitData['nfe.CNPJ'] = str_replace(array('.', '/', '-'), array('', '', ''), Mage::getStoreConfig('doit_easynfe/emit/cnpj'));
        $aEmitData['nfe.xNome'] = Mage::getStoreConfig('doit_easynfe/emit/nome');
        
        $aEmitData['nfe.enderEmit']['nfe.xLgr'] = Mage::getStoreConfig('doit_easynfe/emit/xlgr');
        $aEmitData['nfe.enderEmit']['nfe.nro'] = Mage::getStoreConfig('doit_easynfe/emit/numero');
        $aEmitData['nfe.enderEmit']['nfe.xBairro'] = Mage::getStoreConfig('doit_easynfe/emit/bairro');
        $aEmitData['nfe.enderEmit']['nfe.cMun'] = Mage::getStoreConfig('doit_easynfe/emit/cmun');
        $aEmitData['nfe.enderEmit']['nfe.xMun'] = ( Mage::getModel('doit_easynfe/directory_country_region_city')->load( Mage::getStoreConfig('doit_easynfe/emit/cmun') )->getName() );
	    $aEmitData['nfe.enderEmit']['nfe.fone'] = (string) Mage::getStoreConfig('doit_easynfe/emit/fone') ? Mage::getStoreConfig('doit_easynfe/emit/fone'): '1130643003' ;

        $aEmitData['nfe.enderEmit']['nfe.UF'] = Mage::getModel('directory/region')->load( Mage::getModel('doit_easynfe/directory_country_region')->load( Mage::getStoreConfig('doit_easynfe/emit/cuf') )->getRegionId() )->getCode();
        $aEmitData['nfe.enderEmit']['nfe.CEP'] = Mage::getStoreConfig('doit_easynfe/emit/cep');
        $aEmitData['nfe.enderEmit']['nfe.cPais'] = Mage::getStoreConfig('doit_easynfe/emit/cpais');
        $aEmitData['nfe.enderEmit']['nfe.xPais'] = Mage::app()->getLocale()->getCountryTranslation(Mage::getModel('doit_easynfe/directory_country')->load(Mage::getStoreConfig('doit_easynfe/emit/cpais'))->getCountryId());
        
        $aEmitData['nfe.IE'] = (string)str_replace(".", "", Mage::getStoreConfig('doit_easynfe/emit/ie'));
        $aEmitData['nfe.CRT'] = (string)Mage::getStoreConfig('doit_easynfe/emit/crt');

        return $aEmitData;
    }

    private function getCustomerUf($mOrderShipment) {
        $mShipping = $mOrderShipment->getOrder()->getShippingAddress();
        return Mage::getModel('doit_easynfe/directory_country_region')->load($mShipping->getRegionId(), 'region_id')->getId();
    }   
    
}
