<?php
define('IG_USERNAME', '');
define('IG_PASS', '');
